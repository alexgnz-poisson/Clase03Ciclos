import UIKit

for i in 1 ... 10 {
    print (i)
}

//while

var contador = 0
while contador < 11{
    print("El numero es \(contador)")
        contador += 1
}

//repeat

var cont = 0
repeat {
    print("Numero es \(cont)")
    cont += 1
} while cont < 11


//Numeros pares

for num in 1 ... 20{
    if(num % 2 == 0){
        print(num)
    }
}

//Arreglo

var arreglo : [Int] = [ ]


//While
var nume = 10
while nume > 0{
    print("La cuenta regresiva es \(nume)")
    nume -= 1
}


//Funciones
func nombreCompleto(){
    let nombre: String = "Enrique Alexander Pavon Gonzalez"
    print(nombre)
}
nombreCompleto()

func completoNombre(nombre:String, apellido:String) -> String{
    let mensaje = "Hola soy \(nombre) \(apellido)"
    return mensaje
}
let resultado = completoNombre(nombre: "Enrique",apellido: "Pavon")
print(resultado)

//Funcion para calcular las areas de las distintas figuras geometricas al menos 5






